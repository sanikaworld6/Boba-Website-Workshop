function button() {
   // Your code here
}